﻿module.exports = client => {
  console.gelen-giden(`Bağnaltın koptu! ${new Date()}`);
};
