﻿const Discord = require('discord.js');

exports.run = (client, message, args) => {
	
    message.channel.send(`**MarsyTürkiye** ** Bot Yeniden Başlatılıyor ** [2018]...`).then(msg => {
    console.log(`BOT: **MarsyTürkiye** Bot u Yenıden başlatmak ıcın yetkın yok...`);
    process.exit(0);
  })
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 4
};

exports.help = {
  name: 'yenidenbaslat',
  description: 'Botu yeniden başlatır.',
  usage: 'yenidenbaslat'
};
