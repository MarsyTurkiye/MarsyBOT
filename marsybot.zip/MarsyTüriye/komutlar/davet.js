﻿const Discord = require('discord.js');
const client = new Discord.Client();
const ayarlar = require('../ayarlar.json');

exports.run = (client, message) => {
  const embed = new Discord.RichEmbed()
  .setTitle("Tıkla ve davet et !")
  .setAuthor("**MarsyTürkiye**", "")
  /*
   * Alternatively, use "#00AE86", [0, 174, 134] or an integer number.
   */
  .setColor(0xff8080)
  .setDescription("**MarsyTürkiye** sunucunuza ekleyip **MarsyTürkiye** ile sunucunuzda arkadaşlarınız ile eğlenebilirsiniz.")
  .setFooter("©️ **MarsyTürkiye** 2018", "")
  .setThumbnail("")
  /*
   * BOTUMUZ SIZIN ICIN.
   */
  .setTimestamp()
  .setURL('http://marsyturkiye.sitem.xyz/')
  
  message.channel.send({embed});
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['bot bilgi', 'botbilgi', 'bb', 'botb', 'bbot', 'hakkında', 'bot hakkında', 'bothakkında'],
  permLevel: 0
};

exports.help = {
  name: 'davet',
  description: 'Bot ile ilgili bilgi verir.',
  usage: 'davet'
};
