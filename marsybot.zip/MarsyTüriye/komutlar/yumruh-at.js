﻿const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = (client, message, params) => {
	if (!message.guild) {
    const ozelmesajuyari = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTimestamp()
    .setAuthor(message.author.username, message.author.avatarURL)
    .addField('**Eğlence Komutları Özel Mesajlarda Kullanılamaz!**')
    return message.author.sendEmbed(ozelmesajuyari); }
    if (message.channel.type !== 'dm') {
      const sunucubilgi = new Discord.RichEmbed()
    .setAuthor('Wuhuuuu! **MarsyTürkiye** Ekranı Krıdın Güzel yumruktu!')
    .setColor(3447003)
    .setTimestamp()
    .setDescription('')
		.setImage(`https://media1.tenor.com/images/4cdbd7e5a7e21c1a89a4f7f580b1495e/tenor.gif?itemid=8922666`)
    return message.channel.sendEmbed(sunucubilgi);
    }
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'yumrukat',
  description: 'Yumruk Atar.',
  usage: 'yumrukat'
};
