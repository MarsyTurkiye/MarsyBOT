﻿const Discord = require('discord.js');
const client = new Discord.Client();
const ayarlar = require('../ayarlar.json');

exports.run = (client, message) => {
  if (message.channel.type !== 'dm') {
    const ozelmesajkontrol = new Discord.RichEmbed()
    .setColor(0x00AE86)
    .setTimestamp()
    .setAuthor(message.author.username, message.author.avatarURL)
    .setDescription('Özel mesajlarını kontrol et. :postbox:');
    message.channel.sendEmbed(ozelmesajkontrol) }
	const pingozel = new Discord.RichEmbed()
    .setTitle("Destek Sunucumuz")
  .setAuthor("MarsyTürkiye | Bilgi", "")
  .setColor(0x00AE86)
  .setDescription("Botumuz Geliştitme Aşamasındadır.")
  .setFooter("©️ 2018 | Marsy BOT", "")
  .setThumbnail("")
  .addField("Destek sunucumuz davet", "Destek sunucumuza Katılmayı Unutmayın https://discord.gg/a5ZA9Yn 😊.")
  .addField("Bilgi | 1", "BOtumuz Sızler Icın Burdadır.", true)
  .addBlankField(true)
  .addField("Bilgi | 2", "Hedefımız 120 Dır..", true);
    return message.author.sendEmbed(pingozel)
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['bot bilgi', 'botbilgi', 'bb', 'botb', 'bbot', 'hakkında', 'bot hakkında', 'bothakkında'],
  permLevel: 0
};

exports.help = {
  name: 'destek',
  description: 'Destek sunucumuzun link atar.',
  usage: 'desteksunucu'
};
