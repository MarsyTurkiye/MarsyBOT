﻿exports.run = async (client, msg, args) => {
   if (!args[0]) return msg.channel.send({embed: {
       color: Math.floor(Math.random() * (0xFFFFFF + 1)),
       description: (`:no_entry_sign: Neden AFK Olucagını Belırtmedın.`)
 }});
  let name = msg.author.username
  if(msg.author.username.startsWith("[AFK]")){
    msg.reply("AFK Sin Zaten AFK Acamasın.")
  }
  else {
    msg.reply(" Marsy**Türk**iy**e :no_entry_sign: **AFK** Modu Ak**tif**..")
     msg.msg.author.username.startsWith(`[AFK]${msg.author.username}`);
  }  
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['hava durumu','havadurumu'],
  permLevel: 0
};

exports.help = {
  name: 'afk',
  description: 'AFK MODUNA GECER.',
  usage: 'afk'
};